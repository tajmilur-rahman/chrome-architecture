#include "foo_Util.h"
#include "foo_Util_inline.h"



namespace foo
{
	namespace Util
	{
		Memorizer::Memorizer()
		{
			size = 0;
			width = 2;
			length = 3;
			weight = 4.5f;
		}

		/*	This is the implementation code for a function.
			It is also called the 'definition' of a function. */
		Memorizer* GetNewMemory(size_t, char*)
		{
			Memorizer* result = new Memorizer();
			result->length = 5;
			result->size = 5;
			return result;
		}

		template<typename T> Stamper<T>::Stamper()
		{
			ptr = 0;
		}


		NestedOuter::NestedInner::NestedInner()
		{
			// empty ctor
		}
		void NestedOuter::NestedInner::SetData(float f)
		{
			mData = f;
		}
		float NestedOuter::NestedInner::GetData()
		{
			return mData;
		}

		NestedOuter::NestedOuter()
		{
			mDuck = new NestedInner();
			mDuck->SetData(3.14f);

			mRabbit = new NestedInner();
			mRabbit->SetData(2.59f);
		}
		NestedOuter::~NestedOuter()
		{
			delete mDuck;
			mDuck = NULL;
			delete mRabbit;
			mRabbit = NULL;
		}
	}
}