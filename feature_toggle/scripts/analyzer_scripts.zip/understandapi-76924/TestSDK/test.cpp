

#include <stdio.h>
#include "classes.h"

int main()
{
	Base* b = new Base();
	char str[] = "foo";

	b->fn_two("foo");
	b->fn_two(str);
	b->fn_six("foo");
	b->fn_six(str);

	printf("\n");

	Derived* d = new Derived();
	d->fn_two(str);
	d->fn_two("foo");
	d->fn_six(str);
	d->fn_six("foo");
	printf("\n");

	Base* bb = d;
	bb->fn_two(str);   // should be calling Derived::fn_two
	bb->fn_two("foo"); // should be calling Derived::fn_two
	bb->fn_six(str);   // should be calling Derived::fn_six
	bb->fn_six("foo"); // should be calling Derived::fn_six
	printf("\n");

	Mommy mommy;
	mommy.goo.i = 5;

}