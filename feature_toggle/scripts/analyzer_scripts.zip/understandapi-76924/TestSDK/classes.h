#pragma once

#pragma warning(4 : 4263)
#pragma warning(4 : 4264)

#include "base.h"
#include "otherbase.h"
#include "foo_Util.h"
// classes are below

/*	This is a derived class.
	It inherits from Base of course.
*/
class Derived : public Base
{
public:
	Derived();
	char* fn_one(const char* buf);
	// some virtual methods
	char* fn_two(char* buf); // different from base signature
	char* fn_two(float flt); // overloaded function
	char* fn_six(const char* buf); // different from base signature, therefore it's not even virtual
}; // These comments come after Derived. See if Understand marks these as 'after' the entity.


// class forward declarations
// We need this to differentiate between declared and defined
class Older;
class Mommy;

// Class Younger also inherits from Base.
class Younger : public Base
{
public:
	Younger();
	char* fn_one(int* val);
	virtual char* fn_two(const char* buf); // ok
};

class Older : public Derived, public OtherBase
{
public:
	Older();
	const char* fn_one(char* buf);
	virtual char* fn_two(const char* buf); // ok
};

class Mommy : public Base, public foo::Util::Memorizer
{
public:
	Mommy();
	char* fn_one(char* buf); 
	virtual char* fn_two(const char* buf); //ok
private:
	int my_priv_int;
	static int my_static_int;
	static int my_defined_static;
	void foom() const;
	static void foob(int, float, const char*, char*, const Older*&, int*);
	enum gofer
	{
		jenna,
		shyla,
		nicola,
		suze,
		ashley
	};
	typedef int indexer;
	typedef float real_number;
protected:
	int my_prot_int;
	static int my_static_prot_int;
	void foop();
	static void foopper();
public:
	int my_pub_int;
	static const int* my_static_pub_int;
	union FPValue
	{
		int i;
		float f;
	};
	FPValue goo;
	char* myBlankFunction(const char*); // Unresolved function
	static const OtherBase* pOBase;
};

class giffer
{
public:
		virtual char* myPureFunction(const char* A, const Older* B, Derived& C) = 0;
protected:
private:
};