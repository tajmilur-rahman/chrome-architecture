#pragma once

class Base
{
public:
	Base();
	char* fn_one(char* buf); // Non Virtual class
	virtual char* fn_two(const char* buf);
	virtual char* fn_two(float flt);
	virtual char* fn_six(char* buf);
};

// A Base Pointer
typedef Base* BasePtr;
// Another Base Pointer
typedef Base* BasePointer;
// Wow, another Base pointer. Make sure Understand picks up these comments.
typedef Base* PointerforBases;

// Make sure understand correctly picks up these comments.
enum DaysOfWeek
{
	Monday,
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Saturday,
	Sunday
};

enum Months
{
	Jan,
	Feb,
	Mar,
	Apr,
	May,
	Jun,
	Jul,
	Aug,
	Sep,
	Oct,
	Nov,
	Dec
};