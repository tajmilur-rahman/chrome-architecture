#include "classes.h"
#include <stdio.h>

Base::Base()
{
	// empty
}
char* Base::fn_one(char* buf) // Non Virtual class
{
	printf("Base::fn_one\n");
	return buf;
}
char* Base::fn_two(const char* buf) // changed this class.
{
	printf("Base::fn_two\n");
	char* moo = new char('m');
	return moo;
}
char* Base::fn_two(float flt)
{
	char* moo = new char('m');
	return moo;
}
char* Base::fn_six(char* buf)
{
	printf("Base::fn_six\n");
	return buf;
}

//===============================================

OtherBase::OtherBase()
{
	// empty
}
char* OtherBase::fn_three(char* buf)
{
	return buf;
}
char* OtherBase::fn_four(const char* buf)
{
	char* moo = new char('m');
	return moo;
}

//===============================================

Derived::Derived()
{
	// empty
}
char* Derived::fn_one(const char* buf)
{
	printf("Derived::fn_one\n");
	char* moop = new char('d');
	return moop;
}
char* Derived::fn_two(char* buf) // want the tool to find this method. Compare it to  Base::fn_two
{
	printf("Derived::fn_two\n");
	char* mop = new char('T');
	return mop;
}
char* Derived::fn_two(float flt)
{
	char* moo = new char('m');
	return moo;
}
char* Derived::fn_six(const char* buf)
{
	printf("Derived::fn_six\n");
	return const_cast<char*>( buf );
}
//===============================================

Younger::Younger()
{
	// empty
}
char* Younger::fn_one(int* val)
{
	char* moo = new char('s');
	return moo;
}
char* Younger::fn_two(const char* buf) // ok
{
	char* moo = new char('y');
	return moo;
}

//===============================================


Older::Older()
{
	// empty
}
const char* Older::fn_one(char* buf)
{
	buf = NULL;
	const char* result = new char('g');
	return result;
}
char* Older::fn_two(const char* buf) // ok
{
	char* moo = new char('z');
	return moo;
}

//===============================================
int Mommy::my_defined_static = 9;
Mommy::Mommy()
{
	// empty
}

char* Mommy::fn_one(char* buf)
{
	return buf;
}

char* Mommy::fn_two(const char* buf) // build warning here?
{
	char* moo = new char('x');
	return moo;
}

void Mommy::foom() const
{
}
void Mommy::foob(int a, float b, const char* c, char* d, const Older*& e, int* f)
{
}
void Mommy::foop()
{
}
void Mommy::foopper()
{
}
//===============================================

