#pragma once

namespace foo
{
	namespace Util
	{
		// Function definition
		char* GetExistingMem(size_t size)
		{
			return new char('s');
		}
	}
}