#include "agreggates.h"


	CMixtureOne::CMixtureOne()
	{
		mfoo = new Derived();
	}
	CMixtureOne::~CMixtureOne()
	{
		delete mfoo;
		mfoo = NULL;
	}
	Derived* CMixtureOne::GetFoo()
	{
		return mfoo;
	}
	void CMixtureOne::SetFoo(Derived* val)
	{
		mfoo = val;
	}

	Younger* CMixtureOne::baz()
	{
		return new Younger();
	}
