#pragma once

class OtherBase
{
public:
	OtherBase();
	char* fn_three(char* buf);
	virtual char* fn_four(const char* buf);
};

class RealInlineMethods
{
public:
	RealInlineMethods() {}
	void AMethod();
};

inline void RealInlineMethods::AMethod()
{

}