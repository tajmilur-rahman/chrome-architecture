#pragma once

#include "classes.h"

#pragma warning(4 : 4263)
#pragma warning(4 : 4264)

class CMixtureOne
{
public:
	CMixtureOne();
	~CMixtureOne();
	Derived* GetFoo();
	void SetFoo(Derived*);
	Derived* mfoo;
	Younger* baz();
};