using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ManagedAPI;

namespace UnitTest
{
	/// <summary>
	/// Summary description for ReferenceTest
	/// </summary>
	[TestClass]
	public class ReferenceTest
	{
		public ReferenceTest()
		{

		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		private static bool mOpenResult;
		[TestInitialize()]
		public void MyTestInitialize()
		{
			mOpenResult = Database.Open(UnderstandGlobalData.GetFileName());
			Assert.IsTrue(mOpenResult);
		}
		//
		// Use TestCleanup to run code after each test has run
		[TestCleanup()]
		public void MyTestCleanup()
		{
			Database.Close();
			mOpenResult = false;
		}
		//
		#endregion

		[TestMethod]
		public void ReferencesTest_Basic()
		{
			if (mOpenResult)
			{
				FileEntity fileEnt = Database.LookupFileEntity("base.h");
				
				Assert.AreEqual("base.h", fileEnt.NameShort);

				Reference[] classRefs = fileEnt.Refs("Define", "Class ~Unknown ~UnNamed");
				Reference baseRef = classRefs[0];

				Assert.AreEqual("C Class Type - base.h(3) - Base", baseRef.ToString());
				Assert.AreEqual(3, baseRef.Line);
				Assert.AreEqual(6, baseRef.Column);

				Assert.IsTrue(null != baseRef.File);
				Assert.AreEqual("base.h", baseRef.File.NameShort);

				Entity this_ent = baseRef.ThisEntity;
				Assert.IsTrue(this_ent != null);

				Assert.AreEqual("C Class Type", baseRef.Kind.NameLong);
				Assert.AreEqual("Class", baseRef.Kind.NameShort);
				Assert.AreEqual("C Class Type", baseRef.KindName);

				Entity scope = baseRef.Scope;
				Assert.AreEqual("base.h", scope.NameShort);
			}
		}

		[TestMethod]
		public void ReferencesTest_Copying()
		{
			FileEntity fileEnt = Database.LookupFileEntity("base.h");

			Assert.AreEqual("base.h", fileEnt.NameShort);

			Reference[] classRefs = fileEnt.Refs("Define", "Class ~Unknown ~UnNamed");
			Reference baseRef = classRefs[0];

			// Make a copy
			Reference copyRef = baseRef;

			Assert.AreEqual("C Class Type - base.h(3) - Base", copyRef.ToString());
			Assert.AreEqual(3, copyRef.Line);
			Assert.AreEqual(6, copyRef.Column);

			Assert.IsTrue(null != copyRef.File);
			Assert.AreEqual("base.h", copyRef.File.NameShort);

			Entity this_ent = copyRef.ThisEntity;
			Assert.IsTrue(this_ent != null);

			Assert.AreEqual("C Class Type", copyRef.Kind.NameLong);
			Assert.AreEqual("Class", copyRef.Kind.NameShort);
			Assert.AreEqual("C Class Type", copyRef.KindName);

			Entity scope = copyRef.Scope;
			Assert.AreEqual("base.h", scope.NameShort);
		}
	}
}
