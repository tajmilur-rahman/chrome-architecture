using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest
{
	public class UnderstandGlobalData
	{
		private static String mUnderStandDatabase = @"F:\Depot\DeveloperTools\maxsdk_tools\UnderstandAPI\TestSDK\TestSDK.udb";
		public static String GetFileName()
		{
			return mUnderStandDatabase;
		}
	}
}
