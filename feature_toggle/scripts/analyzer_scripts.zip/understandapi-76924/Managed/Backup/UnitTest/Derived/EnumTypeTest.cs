using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ManagedAPI;

namespace UnitTest.Derived
{
	/// <summary>
	/// Summary description for EnumTypeTest
	/// </summary>
	[TestClass]
	public class EnumTypeTest
	{
		public EnumTypeTest()
		{
			
		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		private static bool mOpenResult;
		[TestInitialize()]
		public void MyTestInitialize()
		{
			mOpenResult = Database.Open(UnderstandGlobalData.GetFileName());
			Assert.IsTrue(mOpenResult);
		}
		//
		// Use TestCleanup to run code after each test has run
		[TestCleanup()]
		public void MyTestCleanup()
		{
			Database.Close();
			mOpenResult = false;
		}
		//
		#endregion

		[TestMethod]
		public void EnumTest_Type()
		{
			if (mOpenResult)
			{
				FileEntity fileEnt = Database.LookupFileEntity("classes.h");
				Assert.AreEqual("classes.h", fileEnt.NameShort);
				ClassType[] classtypes = fileEnt.GetClassTypeDefinitions();
				ClassType mommy = classtypes[3];
				EnumType [] enumEnts = mommy.GetEnums();
				Assert.AreEqual(1, enumEnts.Length);
				EnumType gofer = enumEnts[0];
				Assert.AreEqual("gofer", gofer.NameShort);
				Assert.AreEqual("C Private Member Enum Type", gofer.KindName);
				Assert.AreEqual(null, gofer.TypeText);
				Assert.AreEqual("enum Mommy::gofer", gofer.ToString());
			}
		}

		[TestMethod]
		public void EnumTest_Enumerators()
		{
			if (mOpenResult)
			{
				FileEntity fileEnt = Database.LookupFileEntity("classes.h");
				ClassType[] classtypes = fileEnt.GetClassTypeDefinitions();
				ClassType mommy = classtypes[3];
				EnumType[] enumEnts = mommy.GetEnums();
				EnumType gofer = enumEnts[0];

				Entity[] goferators = gofer.GetEnumerators();
				Assert.IsTrue(null != goferators);
				Assert.AreEqual(5, goferators.Length);

				Assert.AreEqual("jenna",  goferators[0].NameShort);
				Assert.AreEqual("shyla",  goferators[1].NameShort);
				Assert.AreEqual("nicola", goferators[2].NameShort);
				Assert.AreEqual("suze",   goferators[3].NameShort);
				Assert.AreEqual("ashley", goferators[4].NameShort);
			}
		}
	}
}
