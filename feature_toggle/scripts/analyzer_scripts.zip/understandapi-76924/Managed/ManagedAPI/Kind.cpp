#include "stdafx.h"

#include "Kind.h"
#include "Util.h"
using namespace System::IO;
using namespace System::Runtime::InteropServices; // for class Marshal
using namespace System::Diagnostics;

namespace ManagedAPI
{
	Kind::Kind()
	{
	}
	Kind::Kind(::UdbKind kind)
	{
		mNativeKind = kind;

		char* kindLongName = udbKindLongname(kind);
		mLongName = gcnew String(kindLongName);

		char* kindShortName = udbKindShortname(kind);
		mShortName = gcnew String(kindShortName);
	}

	String^ Kind::NameShort::get()
	{
		return mShortName;
	}

	String^ Kind::NameLong::get()
	{
		return mLongName;
	}
	::UdbKind Kind::ThisKind::get()
	{
		return mNativeKind;
	}
	ManagedAPI::Kind^ Kind::Inverse::get()
	{
		::UdbKind kind = udbKindInverse(mNativeKind);
		ManagedAPI::Kind^ kindResult = gcnew Kind(kind);
		return kindResult;
	}

	bool Kind::IsKind(String^ kind_string)
	{
		char* lpszKindString =  Util::StringToChar(kind_string);
		int match = udbIsKind((::UdbKind)mNativeKind, lpszKindString);
		Util::FreeNativeString(lpszKindString);
		lpszKindString = 0;

		bool result = (match == 1);
		return result;
	}
	bool Kind::IsKindFile()
	{
		int match = udbIsKindFile((::UdbKind)mNativeKind);
		bool result = (match > 0);
		return result;
	}
}