#include "stdafx.h"

#pragma managed
#include "Lexer.h"

namespace ManagedAPI
{
	Lexeme::Lexeme()
	{

	}
	Lexeme::Lexeme(UdbLexeme lex)
		: mlex(lex)
	{
		
	}
	Lexeme::~Lexeme()
	{

	}
	Lexeme::!Lexeme()
	{
		
	}

	String^ Lexeme::Text::get()
	{
		char* text = udbLexemeText(mlex);
		String^ result = gcnew String(text);
		return result;
	}
	int Lexeme::LineBegin::get()
	{
		return udbLexemeLineBegin(mlex);
	}
	int Lexeme::LineEnd::get()
	{
		return udbLexemeLineEnd(mlex);
	}
	int Lexeme::ColumnBegin::get()
	{
		return udbLexemeColumnBegin(mlex);
	}
	int Lexeme::ColumnEnd::get()
	{
		return udbLexemeColumnEnd(mlex);
	}
	bool Lexeme::Active::get()
	{
		return (1 != udbLexemeInactive(mlex));
	}
	ManagedAPI::UdbToken Lexeme::Token::get()
	{
		ManagedAPI::UdbToken token = static_cast<ManagedAPI::UdbToken>( udbLexemeToken(mlex) );
		return token;
	}
	Lexeme^ Lexeme::Next::get()
	{
		UdbLexeme lexnext = udbLexemeNext(mlex);
		return gcnew Lexeme(lexnext);
	}
	Lexeme^ Lexeme::Previous::get()
	{
		UdbLexeme lexprev = udbLexemePrevious(mlex);
		return gcnew Lexeme(lexprev);
	}
	Reference^ Lexeme::GetReference()
	{
		UdbReference lexRef = udbLexemeReference(mlex);
		return gcnew Reference(lexRef);
	}

	// ======================================================
	// Lexer definitions
	// ======================================================
	Lexer^ Lexer::Create(UdbEntity entity)
	{
		UdbLexer lexer;
		::UdbStatus status = udbLexerNew(entity, 1, &lexer);
		switch (status)
		{
			case Udb_statusOkay:
				{
					// ok,
					break;
				}
			case Udb_statusLexerFileModified:
			case Udb_statusLexerFileUnreadable:
			case Udb_statusLexerUnsupportedLanguage:
			default: 
				return nullptr;
		}

		Lexer^ result = nullptr;
		if (lexer != nullptr)
		{
			result = gcnew Lexer(lexer);
		}
		return result;
	}
	Lexer::Lexer()
	{

	}
	Lexer::Lexer(UdbLexer lexer)
		: mLexer(lexer)
	{
		mNumLines = udbLexerLines(lexer);
	}
	Lexer::~Lexer()
	{
		
	}
	Lexer::!Lexer()
	{
		udbLexerDelete(mLexer);
	}
	Lexeme^ Lexer::First::get()
	{
		UdbLexeme lexme = udbLexerFirst(mLexer);
		return gcnew Lexeme(lexme);
	}
	int Lexer::Lines::get()
	{
		return mNumLines;
	}
	Lexeme^ Lexer::GetLexeme(int line, int column)
	{
		UdbLexeme lex = udbLexerLexeme(mLexer, line, column);
		return gcnew Lexeme(lex);
	}
	
}