#pragma once

#pragma managed

namespace ManagedAPI
{
	public enum class UdbCommentStyle
	{
		Udb_commentStyleDefault = 0,
		Udb_commentStyleAfter = 1,
		Udb_commentStyleBefore = 2,
		Udb_commentStyleBoth = 3,
		Udb_commentStyleLongest = 4
	};

	public enum class UdbCommentFormat
	{
		Udb_commentFormatDefault = 0
	};

	public enum class UdbLanguage
	{
		Udb_language_NONE = 0x00,
		Udb_language_ALL = 0x3F,
		Udb_language_Ada = 0x01,
		Udb_language_C = 0x02,
		Udb_language_CSharp = 0x04,
		Udb_language_Fortran = 0x08,
		Udb_language_Java = 0x10,
		Udb_language_Jovial = 0x20,
		Udb_language_Pascal = 0x40
	};


	public enum class UdbMetricKind
	{
		Udb_mkind_NONE = 0,
		Udb_mkind_Integer,
		Udb_mkind_Real
	};


	public enum class UdbStatus
	{
		Udb_statusOkay = 0,
		Udb_statusDBAlreadyOpen = 1,
		Udb_statusDBBusy = 2,	// not used
		Udb_statusDBChanged = 3,
		Udb_statusDBCorrupt = 4,
		Udb_statusDBOldVersion = 5,
		Udb_statusDBUnknownVersion = 6,
		Udb_statusDBUnableCreate = 7,
		Udb_statusDBUnableDelete = 8,
		Udb_statusDBUnableModify = 9,
		Udb_statusDBUnableOpen = 10,
		Udb_statusDBUnableWrite = 11,
		Udb_statusDemoAnotherDBOpen = 12,
		Udb_statusDemoInvalid = 13,
		Udb_statusDrawNoFont = 14,
		Udb_statusDrawNoImage = 15,
		Udb_statusDrawTooBig = 16,
		Udb_statusDrawUnableCreateFile = 17,
		Udb_statusDrawUnsupportedFile = 18,
		Udb_statusLexerFileModified = 19,
		Udb_statusLexerFileUnreadable = 20,
		Udb_statusLexerUnsupportedLanguage = 21,
		Udb_statusNoApiLicense = 22,
		Udb_statusNoApiLicenseAda = 23,
		Udb_statusNoApiLicenseC = 24,
		Udb_statusNoApiLicenseFtn = 25,
		Udb_statusNoApiLicenseJava = 26,
		Udb_statusNoApiLicenseJovial = 27,
		Udb_statusNoApiLicensePascal = 28,
		Udb_statusReportUnableCreate = 29,
		Udb_statusReportUnableDelete = 30,
		Udb_statusReportUnableWrite = 31,
		Udb_statusUserAbort = 32,
		Udb_status_LAST
	};


	public enum class UdbToken
	{
		Udb_tokenEOF = 0,
		Udb_tokenComment = 1,
		Udb_tokenContinuation = 2,
		Udb_tokenEndOfStatement = 3,
		Udb_tokenIdentifier = 4,
		Udb_tokenKeyword = 5,
		Udb_tokenLabel = 6,
		Udb_tokenLiteral = 7,
		Udb_tokenNewline = 8,
		Udb_tokenOperator = 9,
		Udb_tokenPreprocessor = 10,
		Udb_tokenPunctuation = 11,
		Udb_tokenString = 12,
		Udb_tokenWhitespace = 13,
		Udb_token_LAST
	};
}