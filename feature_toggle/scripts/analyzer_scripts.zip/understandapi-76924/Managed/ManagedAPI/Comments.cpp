// ManagedAPI.h
#include "stdafx.h"

#pragma managed
#include "Comments.h"

using namespace System;
using namespace System::Collections::Generic;

namespace ManagedAPI
{
	Comments::Comments(UdbEntity entity)
	{

#ifndef LAZY_INIT
		char* DECLAREIN_KIND_TEXT = "Declarein";
		char* DEFINEIN_KIND_TEXT = "Definein";

		char* commentsBefore = udbComment( entity, Udb_commentStyleBefore, Udb_commentFormatDefault, udbKindParse(DEFINEIN_KIND_TEXT) );
		mDefineBefore     = gcnew String(commentsBefore);
		char* commentsDeclareBefore = udbComment( entity, Udb_commentStyleBefore, Udb_commentFormatDefault, udbKindParse(DECLAREIN_KIND_TEXT) );
		mDeclareBefore = gcnew String(commentsDeclareBefore);

		char* commentsAfter = udbComment( entity, Udb_commentStyleAfter, Udb_commentFormatDefault, udbKindParse(DEFINEIN_KIND_TEXT) );
		mDefineAfter = gcnew String(commentsAfter);
		char* commentsDeclareAfter = udbComment( entity, Udb_commentStyleAfter, Udb_commentFormatDefault, udbKindParse(DECLAREIN_KIND_TEXT) );
		mDeclareAfter = gcnew String(commentsDeclareAfter);

		mDefineBeforeRaw  = InitializeRawComments(entity, DEFINEIN_KIND_TEXT);
		mDeclareBeforeRaw = InitializeRawComments(entity, DECLAREIN_KIND_TEXT);
#endif

	}

	Comments::Comments()
	{

	}

	// empty dtor
	Comments::~Comments()
	{

	}

	// Comments on an entity definition
	String^ Comments::DefineBefore::get()
	{
		return mDefineBefore;
	}

	String^ Comments::DefineAfter::get()
	{
		return mDefineAfter;
	}

	ReadOnlyCollection<String^>^ Comments::DefineBeforeRaw::get()
	{
		return mDefineBeforeRaw;
	}

	// Comments on an entity declaration
	String^ Comments::DeclareBefore::get()
	{
		return mDeclareBefore;
	}

	String^ Comments::DeclareAfter::get()
	{
		return mDeclareAfter;
	}

	ReadOnlyCollection<String^>^ Comments::DeclareBeforeRaw::get()
	{
		return mDeclareBeforeRaw;
	}

	ReadOnlyCollection<String^>^ Comments::InitializeRawComments(UdbEntity ent, char* kind)
	{
		List<String^>^ resultComments = gcnew List<String^>();
		int numComments = 0;
		char** comments = 0;
		udbCommentRaw( ent, Udb_commentStyleBefore, udbKindParse(kind), &comments , &numComments);
		for (int i = 0; i < numComments; i++)
		{
			char* tempComment = comments[i];
			if (tempComment != 0)
			{
				String^ acomment = gcnew String(tempComment);
				resultComments->Add(acomment);
			} 
		}
		ReadOnlyCollection<String^>^ result = gcnew ReadOnlyCollection<String^>(resultComments);
		return result;
	}
}
