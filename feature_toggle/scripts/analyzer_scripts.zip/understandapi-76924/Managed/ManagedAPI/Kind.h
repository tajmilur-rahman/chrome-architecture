// ManagedAPI.h

#pragma once

#pragma unmanaged
#include "src\udb.h"

#pragma managed
#include "UdbEnumWrappers.h"

using namespace System;

namespace ManagedAPI
{
	public ref class Kind
	{
	public:
		Kind(::UdbKind);
		property String^ NameLong { String^ get(); }
		property String^ NameShort{	String^ get(); }
		property ::UdbKind ThisKind {	::UdbKind get(); }
		property ManagedAPI::Kind^ Inverse { ManagedAPI::Kind^ get(); }
		
		bool IsKind(String^);
		bool IsKindFile();

	private:
		Kind();
		::UdbKind mNativeKind;
		String^ mLongName;
		String^ mShortName;
	};
}
