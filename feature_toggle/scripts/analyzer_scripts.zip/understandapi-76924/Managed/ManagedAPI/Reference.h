// ManagedAPI.h

#pragma once

#pragma unmanaged
#include "src\udb.h"

#pragma managed
#include "UdbEnumWrappers.h"

#include "Kind.h"

using namespace System;
using namespace System::Collections::Generic;

namespace ManagedAPI
{
	// forward declaration
	ref class Entity;

	public ref class Reference
	{
	public:
		//static Reference^ Create(const UdbReference&);
		Reference(const UdbReference&);
		// file Entities don't reference themselves, hence the pointer is null;
		property Entity^ File { Entity^ get(); }
		property int     Line { int get();	}
		property int     Column 	{ int get(); }
		property Entity^ ThisEntity {	Entity^ get();	}
		property ManagedAPI::Kind^ Kind { ManagedAPI::Kind^ get(); }
		property String^ KindName { String^ get(); }
		property Entity^ Scope {	Entity^ get();	}
		virtual String^ ToString() override;
	private:
		Reference();
		~Reference();
		Entity^ mFile;
		int     mLine;
		int     mColumn;
		Entity^ mThisEnt;
		ManagedAPI::Kind^ mKind;
		String^ mKindString;
		Entity^ mScope;

		//static Dictionary<IntPtr, Reference^>^ sRefList = gcnew Dictionary<IntPtr, Reference^>();
	};


}
