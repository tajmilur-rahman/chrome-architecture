// ManagedAPI.h

#pragma once

#pragma unmanaged
#include "src\udb.h"

#pragma managed
#include "UdbEnumWrappers.h"
#include "Entity.h"
#include "Derived/FileEntity.h"

using namespace System;

namespace ManagedAPI
{
	public ref class Database sealed
	{
	public:
		static bool Open( String^ file_name );
		static void Close();
		static UdbLanguage Language();
		static String^ LanguageString();
		static String^ FileName();
		static array<Entity^>^ GetAllEntities();
		static array<Entity^>^ GetFileEntities();
		// Get Derived types ---------------------------
		static array<FileEntity^>^ GetFileEntityArray();
		static array<ClassType^>^ GetAllClassTypes();
		static array<ClassType^>^ GetAllStructTypes();
		static array<Entity^>^ GetAllEnums();
		static array<Entity^>^ GetAllTypeDefs();
		static array<MethodType^>^ GetAllFunctions();
		static FileEntity^ LookupFileEntity(String^);
		static Entity^ LookupEntitybyReference(Type^, String^, String^, int, int);
		static Entity^ LookupEntity(Type^, String^, String^);
		
		static Entity^ LookupFile(String^);
		static Entity^ LookupEntityByUniqueName(String^);
	private:
		// A typedef for a function pointer. Functions with this signature
		// are used in understand 4 c++ to get generic lists of Udb Entities from
		// the understand database.
		// For more on function pointers see
		// http://www.newty.de/fpt/index.html
		typedef void (*understand_function)(UdbEntity** list, int* items);
		// Two functions share this: GetAllClassTypes and GetAllStructTypes
		static array<ClassType^>^ GetClassStruct(char* );
		static array<Entity^>^ GetEntities(understand_function function_pointer, bool);
		static Entity^ FactoryCreate(Type^, UdbEntity);
		static bool mOpened;
	};
}
