#pragma once

#pragma unmanaged

#pragma managed
#include "..\Entity.h"
#include "..\Lexer.h"
#include "ClassType.h"
using namespace System::Collections::Generic;

namespace ManagedAPI
{
	public ref class FileEntity : public Entity
	{
	public:
		// Static factory Method. Use this to instantiate a FileEntity
		static FileEntity^ Create(const UdbEntity&);
		// Clears all FileEntities stored in the static Dictionary. Should not be 
		// called except in one place, when the Database is shutdown.
		static void Clear();
		
		// Gets all the function entities that are defined inside the file
		array<MethodType^>^ GetFunctionDefinitions();
		// Gets all the function entities that are defined inside the file
		array<MethodType^>^ GetFunctionDeclarations();
		// Gets all the namespace entities that are defined inside the file
		array<Entity^>^ GetNamespacesDeclarations();

		// Gets all the class entities that are defined inside the file
		array<ClassType^>^ GetClassTypeDefinitions();
		// Gets all the struct entities that are defined inside the file
		array<ClassType^>^ GetStructTypeDefinitions();
		// Gets all the Enum definitions that are global inside the file. That is enums that are not
		// inside of a class definition.
		array<Entity^>^ GetEnumDefintions();

		Lexer^ GetLexer();
		
	protected:
		// Protected constructor, use the Create method to instantiate a FileEntity
		FileEntity(const UdbEntity&);

	private:
		// Contains a dynamically allocated list of function definitions that reside inside this File.
		// This member is created and initialized the first time GetClassDefinitions is called.
		array<MethodType^>^ mFunctionDefinitions;
		// Contains a dynamically allocated list of function definitions that reside inside this File.
		// This member is created and initialized the first time GetClassDefinitions is called.
		array<MethodType^>^ mFunctionDeclarations;
		// Contains a dynamically allocated list of namespace definitions that reside inside this File.
		// This member is created and initialized the first time GetNamespacesDeclarations is called.
		array<Entity^>^ mNamespaceDefinitions;

		// Contains a dynamically allocated list of class definitions that reside inside this File.
		// This member is created and initialized the first time GetClassDefinitions is called.
		array<ClassType^>^ mClassTypeDefinitions;
		array<ClassType^>^ mStructTypeDefinitions;

		array<Entity^>^ mEnumDefinitions;

		// Get's File References for the Entity
		array<UdbEntity>^ GetFileRefs(char*, char*);

		static Dictionary<String^, FileEntity^>^ msFileList = gcnew Dictionary<String^, FileEntity^>();

		template<typename T> array<T^>^ ConvertEntities(char*, char*);
	};
}