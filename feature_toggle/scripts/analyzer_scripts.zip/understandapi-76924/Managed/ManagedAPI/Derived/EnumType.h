#pragma once

#pragma unmanaged

#pragma managed
#include "..\Entity.h"
using namespace System::Collections::Generic;

namespace ManagedAPI
{
	public ref class EnumType : public Entity
	{
	public:
		static EnumType^ Create(const UdbEntity&);
		static void Clear();
		virtual String^ ToString() override;
		array<Entity^>^ GetEnumerators();
	protected:
		// Protected constructor, use the Create method to instantiate a EnumType
		EnumType(const UdbEntity&);
	private:
		array<Entity^>^ mEnumerators;
		static Dictionary<String^, EnumType^>^ mEnumList = gcnew Dictionary<String^, EnumType^>();
	};
}