// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

// NOTE:
// This library does not include the C header file for the Understand 4 c++ API.
// That file is proprietary and I cannot redistribute it here.
// You will need to purchase the application first in order to get the API header file
// which is called udb.h
#include "src/udb.h"

/*	For resolving Linker Error 4245:
	warning LNK4248: unresolved typeref token (01000014) for 'UdbKindList_'; image may not run	KindList.obj

	To Solve, answer is given by 
	Ronald Laeremans
	[Visual C++ team]

	"Add empty definitions of both structures. The linker will do that 
	automatically for you in VC 2005 (and give a warning).

	This is because the CLR internally does not support using a pointer to an 
	undefined class. These 2 structures are never defined in the Windows 
	headers. In native C++ this is not an error as long as you don't try to 
	deference anything of it, in the CLR just creating the pointer is illegal." */
struct UdbReference_ {};
struct UdbEntity_ {};
struct UdbKindList_ {};
struct UdbLexer_ {};
struct UdbLexeme_ {};