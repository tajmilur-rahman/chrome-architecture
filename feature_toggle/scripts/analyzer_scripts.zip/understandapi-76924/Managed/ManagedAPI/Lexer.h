#pragma once

#pragma unmanaged
#include "src\udb.h"

#pragma managed
#include "UdbEnumWrappers.h"
#include "Reference.h"
using namespace System;

namespace ManagedAPI
{
	public ref class Lexeme
	{
	public:
		Lexeme();
		Lexeme(UdbLexeme);
		~Lexeme();
		!Lexeme();

		property String^  Text { String^ get(); }
		property ManagedAPI::UdbToken Token { ManagedAPI::UdbToken get(); }
		property int  LineBegin { int get(); }
		property int  LineEnd { int get(); }

		property int  ColumnBegin { int get(); }
		property int  ColumnEnd { int get(); }
		property bool Active { bool get(); }

		property Lexeme^ Next { Lexeme^ get(); }
		property Lexeme^ Previous { Lexeme^ get(); }

		Reference^ GetReference();
	private:
		UdbLexeme mlex;
	};


	public ref class Lexer
	{
	private:
		Lexer();
		Lexer(UdbLexer);
	public:
		static Lexer^ Create(UdbEntity);
		~Lexer();
		!Lexer();
		
		property Lexeme^ First { Lexeme^ get(); }
		property int     Lines { int get(); }

		Lexeme^ GetLexeme(int, int);
	private:
		// this owns the memory for the lexer, and free's it when it's finished.
		UdbLexer mLexer;
		int mNumLines;
	};
}