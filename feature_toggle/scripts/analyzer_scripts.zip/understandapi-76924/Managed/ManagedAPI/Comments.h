// ManagedAPI.h

#pragma once

#pragma unmanaged
#include "src\udb.h"

#pragma managed

using namespace System;
using namespace System::Collections::ObjectModel;

namespace ManagedAPI
{
	/*	Class that represents comments on an entity
		Comments were becoming so complicated that I decided to refactor them out to their
		own file.
		In C/C++ an entity can be declared in one place, and defined in another place.
		Therefore I felt the comments need to similarly be seperated.
	*/
	public ref class Comments
	{
	public:
		Comments(UdbEntity);
		~Comments();
		// Comments on an entity definition
		property String^ DefineBefore     { String^ get(); }
		property String^ DefineAfter      { String^ get(); }
		property ReadOnlyCollection<String^>^ DefineBeforeRaw  { ReadOnlyCollection<String^>^ get(); }

		// Comments on an entity declaration
		property String^ DeclareBefore    { String^ get(); }
		property String^ DeclareAfter     { String^ get(); }
		property ReadOnlyCollection<String^>^ DeclareBeforeRaw { ReadOnlyCollection<String^>^ get(); }

	private:
		Comments();
		// Initializes Raw comments.
		static ReadOnlyCollection<String^>^ InitializeRawComments(UdbEntity ent, char* kind);

		String^ mDefineBefore;
		String^ mDefineAfter;
		ReadOnlyCollection<String^>^ mDefineBeforeRaw;
		
		String^ mDeclareBefore;
		String^ mDeclareAfter;
		ReadOnlyCollection<String^>^ mDeclareBeforeRaw;
	};
}
