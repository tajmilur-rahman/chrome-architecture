// ManagedAPI.h

#pragma once

#pragma unmanaged
#include "src/udb.h"

#pragma managed
#include "UdbEnumWrappers.h"
#include "Entity.h"

using namespace System;
using namespace System::Collections::Generic;

namespace ManagedAPI
{
	public ref class Util
	{
	public:
		static char* StringToChar( String^);
		static void FreeNativeString(const char*);
		static array<Entity^>^ ReferenceToEntityArray( array<Reference^>^ );
		static String^ CleanUpType(String^);
	};
}
